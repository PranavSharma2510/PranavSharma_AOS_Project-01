package Lifegame;

public interface BoardController {
	
	public void updated(BoardModel m);
	
}
